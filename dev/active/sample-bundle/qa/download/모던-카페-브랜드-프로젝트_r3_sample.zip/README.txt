디자인 샘플 묶음 — 파일 5개
design.png: 시안 화면 이미지(현재 미리보기 폭)
design.html: 시안 HTML 1개(글꼴·이미지 포함)
design-tokens.json: 색·글꼴·간격·모서리 토큰과 CSS 변수(--site-*)
sections.json: 섹션 순서·유형·변형·톤·모션(글·이미지 값 없음)
